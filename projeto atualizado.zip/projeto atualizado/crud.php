<?php 

	$host = "localhost";
	$user = "root";
	$pass = "";
	$bd = "clube";
?>
<form >
	<input type="text"  name="nome" placeholder="nome" required>
	<input type="text"  name="email" placeholder="email" required>
	<input type="password"  name="senha" placeholder="Senha" required>
	<input type="submit" placeholder="cadastrar">
	<input type="submit" placeholder="editar">
	<input type="submit" placeholder="remover">
	
</form>