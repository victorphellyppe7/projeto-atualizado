
<!DOCTYPE html>
<html>
    <head>
        <META charset="UTF-8"> 
        <title>Clube do Livro </title>
        <link href="css/clube.css" rel="stylesheet">
       
    </head>
    <body class="fundo">

	<br><br><br><br><br>
	<div class="geral">  



   <fieldset>
       <legend>Login</legend>
<form name="autentication" method="post" action="autentication.php">

    	
        <td><input type="text" placeholder="Email" name="email" required></td></tr>

	    	<td><input type="password" placeholder="senha" name="senha" required></td></tr>

    	<tr><td><input type="submit" name="botao" value="Entrar"></td></tr>
                        <input type="button" value="Voltar" onClick="history.go(-1)"> 

	
</form>
   </fieldset>

    <br><br>
    	
</div>        
		
	</body>
</html>