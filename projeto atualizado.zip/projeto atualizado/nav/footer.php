<footer id="roda">
			Equipe : Nicholas Torres | Victor Phellyppe
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			<?php 
			date_default_timezone_set('America/Sao_Paulo');
echo $data = date("d/m/Y H:i:s");

?>
		</footer>

		
	</body>
</html>
