		<nav id="menu">
		<ul>
			<li><a class="links" href="index2.php"><b>Livros</b></a></li>
			<li><a class="links" href="produto2.php"><b>Exibir Usuários</b></a></li>
			
			<li><a class="links" href="logout.php"><b>Logout</b></a></li>
		</ul>
		</nav>