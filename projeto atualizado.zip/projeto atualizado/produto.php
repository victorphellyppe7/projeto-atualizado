<?php
require("nav/header.php");
?>
<?php
require("nav/menu.php");
?>		
		<div class="product">
		
		
		
			<div style="float:left" >
				<img src="imagens\1.jpg">
			</div>
			
			<div style="clear:right">
				<p class="Tamletra"> <b>Guerra dos Tronos - As Cronicas de Gelo e Fogo, Vol: 1</b></p>
				<p style="color:" align="left"> “A Guerra dos Tronos” 
Em uma terra onde o verão pode durar décadas e o inverno toda uma vida, os problemas estão apenas começando. O frio está de volta e, nas florestas ao norte de Winterfell, forças sobrenaturais se espalham por trás da Muralha que protege a região. No centro do conflito estão os Stark do reino de Winterfell, uma família tão áspera quanto as terras que lhe pertencem.
Dos lugares onde o frio é brutal até os distantes reinos de plenitude e sol, George R. R. Martin narra uma história de lordes e damas, cavaleiros e mercenários, assassinos e bastardos, que se juntam em um tempo de presságios malignos. Entre disputas por reinos, tragédias e traições, vitória e terror, o destino dos Stark, seus aliados e seus inimigos é incerto. Mas cada um está se esforçando para ganhar este conflito mortal: a guerra dos tronos.</p>
				<br>
				<div><button type="button"" disabled="disabled"><a href="avaliar.html" class="retirarHyperlink">Avaliar Livro!</a></button></div>
			</div>
		</div>
		<br>
		<br>
		<div class="product">
		
			<div style="float:left" >
				<img src="imagens\2.png" class="imagemL">
			</div>
			<div style="clear:right">
				<p class="Tamletra"> <b>Furia dos Reis - As Cronicas de Gelo e Fogo, Vol: 2</b></p>
				<p style="color:" align="left"> Em 'A fúria dos reis', o segundo livro da aclamada série As crônicas de gelo e fogo, George R. R. Martin segue a épica aventura nos Sete Reinos, onde muitos perigos e disputas ainda estão por vir. Além dos combates que se estendem por todos os lados, a ameaça agora também chega pelo céu!
Mistério, intriga, romance e aventura encherão as páginas deste livro, agora também um seriado de sucesso da HBO!
“A FÚRIA DOS REIS” 
Quando um cometa vermelho cruza os céus de Westeros, os Sete Reinos estão em plena guerra civil. Os exércitos dos Stark e dos Lannister estão se preparando para o confronto final, e Stannis – irmão do falecido Rei Robert –, desejoso de possuir um exército que lute pela sua reivindicação ao trono, alia-se a uma misteriosa religião oriental. Porém, seu irmão mais novo também se proclama rei. E, enquanto isso, os Greyjoy planejam vingança contra todos os que os humilharam dez anos atrás. Ainda, no distante Leste, poderosos dragões estão prestes a chegar aos Sete Reinos, trazendo fogo e morte... Um perigo de proporções gigantescas, muito maior do que as grandes guerras!
Nesta tão esperada sequência de A guerra dos tronos, George R. R. Martin cria uma obra de incrível poder e imaginação. A fúria dos reis nos transporta até um mundo de glória e vingança, de guerras e magia, onde poder e miséria podem se alterar no virar de uma página. Uma obra singular da literatura fantástica.</p>
				<br>
				<div><button type="button" disabled="disabled"><a href="avaliar.html" class="retirarHyperlink">Avaliar Livro!</a></button></div>
			</div>
		</div>

		<br>
		<br>
		<div class="product">
		
			<div style="float:left" >
				<img src="imagens\3.jpg" class="imagemL">
			</div>
			<div style="clear:right">
				<p class="Tamletra"> <b>Tormenta de Espadas - As Cronicas de Gelo e Fogo, Vol: 3</b></p>
				<p style="color:" align="left"> A tormenta de espadas, o terceiro livro da série de George R. R. Martin, onde os Sete Reinos já sentem o rigoroso inverno que chega, mas as batalhas parecem estar mais cruéis e impiedosas. Enquanto os Sete Reinos estremecem com a chegada dos temíveis selvagens pela Muralha, numa maré interminável de homens, gigantes e terríveis bestas, Jon Snow, o Bastardo de Winterfell, que se encontra entre eles, divide-se entre sua consciência e o papel que é forçado a desempenhar. Robb Stark, o Jovem Lobo, vence todas as suas batalhas, mas será que ele conseguirá vencer os desafios que não se resolvem apenas com a espada? Arya continua a caminho de Correrrio, mas mesmo alguém tão desembaraçado como ela terá grande dificuldade em ultrapassar os obstáculos que se aproximam. Na corte de Joffrey, em Porto Real, Tyrion luta pela vida, depois de ter sido gravemente ferido na Batalha da Água Negra; e Sansa, livre do compromisso com o homem que agora ocupa o Trono de Ferro, precisa lidar com as consequências de ser a segunda na linha de sucessão de Winterfell, uma vez que Bran e Rickon estariam mortos. No Leste, Daenerys Targaryen navega em direção às terras da sua infância, mas antes ela precisará aportar às desprezíveis cidades dos esclavagistas. Mas a menina indefesa agora é uma mulher poderosa. Quem sabe quanto tempo falta para se transformar em uma conquistadora impiedosa?</p>
				<br>
				<div><button type="button" disabled="disabled"><a href="avaliar.html" class="retirarHyperlink">Avaliar Livro!</a></button></div>
			</div>
		</div> 

		<br>
		<br>
		<div class="product">
		
			<div style="float:left" >
				<img src="imagens\4.png" class="imagemL">
			</div>
			<div style="clear:right">
				<p class="Tamletra"> <b>O Festim Dos Corvos - As Cronicas de Gelo e Fogo, Vol: 4</b></p>
				<p style="color:" align="left"> Continuando a saga mais ambiciosa e imaginativa desde “O Senhor dos Anéis”, “As Crônicas de Gelo” e “Fogo” prosseguem após o violento triunfo dos traidores. Enquanto os senhores do Norte lutam incessantemente uns contra os outros e os Homens de Ferro estão prestes a emergir como uma força implacável, a rainha regente Cersei tenta manter intacta a força dos leões em Porto Real. Os jovens lobos, sedentos por vingança, estão dispersos pela terra, cada um envolvido no perigoso jogo dos tronos. Arya abandonou Westeros rumo a Bravos, Bran desapareceu na vastidão enigmática para além da Muralha, Sansa está nas mãos do ambicioso e maquiavélico Mindinho, Jon Snow foi proclamado comandante da Muralha mas tem que enfrentar a vontade férrea do rei Stannis e, no meio de toda a intriga, começam a surgir histórias do outro lado do mar sobre dragões vivos e fogo... Quando Euron Greyjoy consegue ser escolhido como rei das Ilhas de Ferro não são só as ilhas que tremem. “O Olho de Corvo” tem o objetivo declarado de conquistar Westeros. E o seu povo parece acreditar nele. Mas será ele capaz? Em Porto Real, Cersei enreda-se cada vez mais nas teias da corte. Desprovida do apoio da família, e rodeada por um conselho que ela própria considera incapaz, é ainda confrontada com a presença ameaçadora de uma nova corrente militante da Fé. Como se desvencilhará de tal enredo?</p>
				<br>
				<div><button type="button" disabled="disabled"><a href="avaliar.html" class="retirarHyperlink">Avaliar Livro!</a></button></div>
			</div>
		</div> 

		<br>
		<br>
		<div class="product">
		
			<div style="float:left" >
				<img src="imagens\5.jpg" class="imagemL">
			</div>
			<div style="clear:right">
				<p class="Tamletra"> <b>A Dança Dos Dragões - As Cronicas de Gelo e Fogo, Vol: 5</b></p>
				<p style="color:" align="left"> O Norte jaz devastado e num completo vazio de poder. A Patrulha da Noite, abalada pelas perdas sofridas para lá da Muralha e com uma grande falta de homens, está nas mãos de Jon Snow, que tenta afirmar-se no comando tomando decisões difíceis respeitantes ao autoritário Rei Stannis, aos selvagens e aos próprios homens que comanda. Para lá da Muralha, a viagem de Bran prossegue. Mas outras viagens convergem para a Baía dos Escravos, onde as cidades dos esclavagistas sangram e Daenerys Targaryen descobre que é bastante mais fácil conquistar uma cidade do que substituir de um dia para o outro todo um sistema político e econômico. Conseguirá ela enfrentar as intrigas e ódios que se avolumam enquanto os seus dragões crescem para se tornarem nas criaturas temíveis que um dia conquistarão os Sete Reinos?</p>
				<br>
				<div><button type="button" disabled="disabled"><a href="avaliar.html" class="retirarHyperlink">Avaliar Livro!</a></button></div>
			</div>
		</div> 						
		
	</body>
</html>