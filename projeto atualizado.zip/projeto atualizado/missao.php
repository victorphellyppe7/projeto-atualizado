<?php
require("nav/header.php");
?>
<?php
require("nav/menu.php");
?>
	<br><br><br><br><br>
	<div id="missao">
	<h1><b>O Clube do Livro foi criado em junho de 2017 e faz parte integrante do Instituto Federal de Alagoas da cidade de Maceió – AL, tendo como objetivo a divulgação e avaliação de livros dos mais variados possíveis, codificada por Nicholas Torres e victor phellyppe, levando ao leitor, leituras edificantes que trazem  consolo e conhecimento.
Toda renda líquida do Clube do Livro será revertida em prol das notas 10 que iremos receber do professor Ricardo. </b></h1>
		
		
	</body>
</html>
